import matplotlib.pyplot as plt
import math
import re
import pandas as pd
import glob

# read csv file
def df_csv(csvfile):
    df = pd.read_csv(csvfile)
    return df

# csvファイルのファイル名のソート
def atoi(text):
    return int(text) if text.isdigit() else text

def natural_keys(text):
    return [ atoi(c) for c in re.split(r'(\d+)', text) ]

# 時刻歴データをつなげる
def df_height_data(csvfile_sort):
    delta = 0.03
    height_list = []

    for csvfile in csvfile_sort:
        height_dict = {}
        height_dict['time(sec)'] = float(re.findall(r"\d+", csvfile)[0])/10
        df_h = pd.DataFrame()    

        df = df_csv(csvfile)
        for point in Hxpoints:
            Hz_mean = df[(df['Points:0']>=Hxpoints[point]-delta) & (df['Points:0']<=Hxpoints[point]+delta)]['Points:2'].mean()
            if math.isnan(Hz_mean) == True: # nan
                height_dict[point] = 0.0
            else:
                height_dict[point] = Hz_mean

        height_list.append(height_dict)

        df_h_ = pd.DataFrame(height_list)
        df_h = pd.concat([df_h, df_h_])
    
    return df_h

# グラフ化
def graph_func(Hxpoints,df_openfoam, df_exp):
    for i, point in enumerate(Hxpoints):
        ax = fig.add_subplot(1, 4, i+1)
        ax.plot(df_exp['Time (s)'].to_numpy(), df_exp[f'{point}'].to_numpy(), color='black',label='Exp data')
        ax.plot(df_openfoam['time(sec)'].to_numpy(), df_openfoam[point].to_numpy(), color='red', label='OpenFOAM ParaView')
        ax.set_xlabel('time(sec)',fontsize=16)
        ax.set_ylabel('height(m)',fontsize=16)
        ax.set_title(f'{point}',fontsize=16)    
        ax.set_xlim(0, 8.0)
        ax.set_ylim(0,0.6)
        ax.grid()
        ax.legend()

if __name__ == '__main__':
    Hxpoints = {
        'H1 (m)':0.496,
        'H2 (m)':0.992,
        'H3 (m)':1.488,
        'H4 (m)':2.638
        }
    
    # csvファイルのリスト化
    csv_file = glob.glob('*.csv')
    csvfile_sort = sorted(csv_file, key=natural_keys)
    df_openfoam = df_height_data(csvfile_sort)

    # csvファイルのリスト化
    df_exp = pd.read_csv('../../exp_data/test_case_2_exp_data.csv',sep='\t')
                         
    # グラフ化（OpenFOAMと実験の比較）
    fig = plt.figure(figsize=(24,4.5))
    plt.subplots_adjust(wspace=0.5, hspace=0.6)


    graph_func(Hxpoints,df_openfoam,df_exp)

    fig.savefig("height.png")
