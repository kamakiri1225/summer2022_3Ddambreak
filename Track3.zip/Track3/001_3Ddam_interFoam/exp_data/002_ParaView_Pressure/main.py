import pandas as pd
import glob
import re
import matplotlib.pyplot as plt
import subprocess


# ファイル名の昇順
def atoi(text):
    return int(text) if text.isdigit() else text

def natural_keys(text):
    return [ atoi(c) for c in re.split(r'(\d+)', text) ]

# P1~P8のグラフ化
def probe_func(i, point):
    list_csv = glob.glob(f'{point}*.csv')
    list_csv_sort = sorted(list_csv, key=natural_keys)

    df = pd.DataFrame()
    for csv_file in list_csv_sort:
        df_ = pd.read_csv(csv_file)
        df_['time'] = float(re.findall(r"\d+", csv_file)[1])/10.0
        df = pd.concat([df,df_])
    
    df['p'] = df['p'].fillna(0.0)
    
    ax = fig.add_subplot(2, 4, i+1)
    ax.plot(df_exp['Time (s)'].to_numpy(), df_exp[f'{point.upper()} (Pa)'].to_numpy(), color='black',label='Exp data')
    ax.plot(df['time'].to_numpy(), df['p'].to_numpy(), color='red', label='OpenFOAM ParaView')
    ax.set_xlabel('x(m)',fontsize=16)
    ax.set_ylabel('Pressure(Pa)',fontsize=16)
    ax.set_title(f'{point}',fontsize=16)    
    ax.set_xlim(0, 8)
    ax.set_ylim(0,10000)
    ax.grid()
    ax.legend()
    
if __name__ == '__main__':
    
    # 指定した座標
    probe_points = {
    'p1':[0.8245001, 0.0, 0.0205],
    'p2':[0.8245001, 0.0, 0.0605],
    'p3':[0.8245001, 0.0, 0.1005],
    'p4':[0.8245001, 0.0, 0.1405],
    'p5':[0.8040   , 0.0, 0.161],
    'p6':[0.7640   , 0.0, 0.161],
    'p7':[0.7240   , 0.0, 0.161],
    'p8':[0.6840, 0.0, 0.161]	
    }

    df_exp = pd.read_csv('../../exp_data/test_case_2_exp_data.csv',sep='\t' )

    #subprocess.run(['pvpython','probe_Alltime.py'])
    fig = plt.figure(figsize=(24,10))
    plt.subplots_adjust(wspace=0.4, hspace=0.6)

    for i, point in enumerate(probe_points):
        probe_func(i, point)
    
    fig.savefig("point.png")
