# trace generated using paraview version 5.7.0
#
# To ensure correct image size when batch processing, please search 
# for and uncomment the line `# renderView*.ViewSize = [*,*]`

#### import the simple module from the paraview
from paraview.simple import *
#### disable automatic camera reset on 'Show'
import os

# 現在のパス
PWD = os.getcwd()

paraview.simple._DisableFirstRenderCameraReset()

# create a new 'OpenFOAMReader'
postfoam = OpenFOAMReader(FileName=f'{PWD}/../../post.foam')

probe_points = {
	'p1':[0.8245, 0.0, 0.021],
	'p2':[0.8245, 0.0, 0.061],
	'p3':[0.8245, 0.0, 0.101],
	'p4':[0.8245, 0.0, 0.141],
	'p5':[0.8035, 0.0, 0.162],
	'p6':[0.7635, 0.0, 0.162],
	'p7':[0.7235, 0.0, 0.162],
	'p8':[0.6835, 0.0, 0.162]	
	}

for point in probe_points:

	#set probe points
	probe = probe_points[point]
	
	# get animation scene
	animationScene1 = GetAnimationScene()

	# get the time-keeper
	timeKeeper1 = GetTimeKeeper()

	# update animation scene based on data timesteps
	animationScene1.UpdateAnimationUsingDataTimeSteps()

	# get active view
	renderView1 = GetActiveViewOrCreate('RenderView')
	# uncomment following to set a specific view size
	# renderView1.ViewSize = [1546, 682]

	# show data in view
	postfoamDisplay = Show(postfoam, renderView1)

	# trace defaults for the display properties.
	postfoamDisplay.Representation = 'Surface'

	# reset view to fit data
	renderView1.ResetCamera()

	# show color bar/color legend
	postfoamDisplay.SetScalarBarVisibility(renderView1, True)

	# update the view to ensure updated data information
	renderView1.Update()

	# get color transfer function/color map for 'p'
	pLUT = GetColorTransferFunction('p')

	# get opacity transfer function/opacity map for 'p'
	pPWF = GetOpacityTransferFunction('p')

	# Properties modified on postfoam
	postfoam.SkipZeroTime = 0

	# update the view to ensure updated data information
	renderView1.Update()

	# create a new 'Probe Location'
	probeLocation1 = ProbeLocation(Input=postfoam,
	    ProbeType='Fixed Radius Point Source')
	    
	# Properties modified on probeLocation1.ProbeType
	probeLocation1.ProbeType.Center = probe
	
	# Properties modified on postfoam
	postfoam.CellArrays = ['U', 'alpha.water', 'alpha.water_0', 'p', 'p_rgh', 'k', 'nut', 'omega']

	# Create a new 'SpreadSheet View'
	spreadSheetView1 = CreateView('SpreadSheetView')
	spreadSheetView1.ColumnToSort = ''
	spreadSheetView1.BlockSize = 1024
	# uncomment following to set a specific view size
	# spreadSheetView1.ViewSize = [400, 400]

	# show data in view
	probeLocation1Display = Show(probeLocation1, spreadSheetView1)

	# get layout
	layout1 = GetLayoutByName("Layout #1")

	# add view to a layout so it's visible in UI
	AssignViewToLayout(view=spreadSheetView1, layout=layout1, hint=0)

	# save data
	SaveData(f'{PWD}/{point}.csv', proxy=probeLocation1, WriteTimeSteps=1)

	#### saving camera placements for all active views

	# current camera placement for renderView1
	renderView1.CameraPosition = [1.6100000143051147, 0.0, 7.294078149091664]
	renderView1.CameraFocalPoint = [1.6100000143051147, 0.0, 0.5]
	renderView1.CameraParallelScale = 1.758436818899806
	

#### uncomment the following to render all views
# RenderAllViews()
# alternatively, if you want to write images, you can use SaveScreenshot(...).
